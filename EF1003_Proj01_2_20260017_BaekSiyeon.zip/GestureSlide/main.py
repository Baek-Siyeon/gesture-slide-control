"""
Program: GestureSlide
Purpose:
    This program controls PowerPoint slides using hand gestures.
    A webcam frame is captured with OpenCV, classified by a
    Teachable Machine exported Keras model, and converted into
    keyboard input using PyAutoGUI.

Target classes from Teachable Machine:
    - Background
    - Next
    - Previous

Required files in the same folder:
    - main.py
    - keras_model.h5
    - labels.txt
"""

# =============================
# Import libraries
# =============================
import cv2
import time
import numpy as np
import pyautogui
from tensorflow.keras.models import load_model

# =============================
# Global configuration values
# =============================

# File paths
MODEL_FILE_PATH = "keras_model.h5"
LABEL_FILE_PATH = "labels.txt"

# Webcam settings
WEBCAM_INDEX = 0
MODEL_INPUT_WIDTH = 224
MODEL_INPUT_HEIGHT = 224

# Decision rule settings
MIN_CONFIDENCE_SCORE = 0.90
MIN_CONSECUTIVE_FRAMES = 5
ACTION_COOLDOWN_SECONDS = 1.0

# Safety setting for PyAutoGUI
pyautogui.FAILSAFE = True


# =============================
# Model and label loading
# =============================
def load_gesture_model(model_path):
    """
    Load the Teachable Machine exported Keras model.

    Args:
        model_path (str): path to keras_model.h5

    Returns:
        model: loaded Keras model
    """
    gesture_model = load_model(model_path, compile=False)
    return gesture_model


def load_class_labels(label_path):
    """
    Load class labels from labels.txt.

    Teachable Machine label files may contain either:
        Background
        Next
        Previous
    or:
        0 Background
        1 Next
        2 Previous

    This function removes the numeric prefix if it exists.

    Args:
        label_path (str): path to labels.txt

    Returns:
        list[str]: cleaned class label names
    """
    with open(label_path, "r", encoding="utf-8") as file:
        raw_lines = [line.strip() for line in file.readlines()]

    cleaned_labels = []
    for line in raw_lines:
        split_line = line.split(maxsplit=1)
        if len(split_line) == 2 and split_line[0].isdigit():
            cleaned_labels.append(split_line[1])
        else:
            cleaned_labels.append(line)

    return cleaned_labels


# =============================
# Frame preprocessing
# =============================
def preprocess_webcam_frame(frame):
    """
    Convert an OpenCV webcam frame into the input format expected
    by the Teachable Machine Keras model.

    Steps:
    1. Resize the frame to 224x224
    2. Convert to float32 NumPy array
    3. Normalize pixel values to [-1, 1]
    4. Add batch dimension so shape becomes (1, 224, 224, 3)

    Args:
        frame (numpy.ndarray): raw webcam frame

    Returns:
        numpy.ndarray: model-ready input array
    """
    resized_frame = cv2.resize(frame, (MODEL_INPUT_WIDTH, MODEL_INPUT_HEIGHT))
    float_frame = np.asarray(resized_frame, dtype=np.float32)
    normalized_frame = (float_frame / 127.5) - 1.0
    batched_frame = np.expand_dims(normalized_frame, axis=0)
    return batched_frame


# =============================
# Prediction logic
# =============================
def predict_gesture(model, labels, frame):
    """
    Predict the gesture label for a single webcam frame.

    Args:
        model: loaded Keras model
        labels (list[str]): class labels
        frame (numpy.ndarray): raw webcam frame

    Returns:
        tuple:
            predicted_label (str)
            predicted_confidence (float)
            full_prediction_vector (numpy.ndarray)
    """
    model_input = preprocess_webcam_frame(frame)
    prediction_vector = model.predict(model_input, verbose=0)

    predicted_index = int(np.argmax(prediction_vector))
    predicted_confidence = float(prediction_vector[0][predicted_index])
    predicted_label = labels[predicted_index]

    return predicted_label, predicted_confidence, prediction_vector[0]


# =============================
# PowerPoint control logic
# =============================
def execute_slide_action(gesture_label):
    """
    Convert a recognized gesture into a PowerPoint keyboard action.

    Args:
        gesture_label (str): predicted gesture label
    """
    if gesture_label == "Next":
        pyautogui.press("right")
        print("Action executed: Next slide")

    elif gesture_label == "Previous":
        pyautogui.press("left")
        print("Action executed: Previous slide")


# =============================
# Stabilization / decision rules
# =============================
def update_stable_gesture_state(
    predicted_label,
    predicted_confidence,
    previous_stable_label,
    previous_frame_count
):
    """
    Update the current stable gesture state.

    Only "Next" and "Previous" with high confidence are allowed
    to continue accumulating frame counts.
    All other states are treated as Background / No Action.

    Args:
        predicted_label (str): current predicted label
        predicted_confidence (float): current confidence score
        previous_stable_label (str or None): previous stable label
        previous_frame_count (int): consecutive count for that label

    Returns:
        tuple:
            new_stable_label (str or None)
            new_frame_count (int)
    """
    target_gestures = ["Next", "Previous"]

    if predicted_label in target_gestures and predicted_confidence >= MIN_CONFIDENCE_SCORE:
        if predicted_label == previous_stable_label:
            return predicted_label, previous_frame_count + 1
        return predicted_label, 1

    return None, 0


def should_execute_action(stable_label, stable_count, last_action_time):
    """
    Decide whether the program should execute a slide action now.

    Conditions:
    1. stable_label must be Next or Previous
    2. stable_count must be large enough
    3. cooldown time must have passed

    Args:
        stable_label (str or None)
        stable_count (int)
        last_action_time (float)

    Returns:
        bool
    """
    current_time = time.time()

    if stable_label not in ["Next", "Previous"]:
        return False

    if stable_count < MIN_CONSECUTIVE_FRAMES:
        return False

    if current_time - last_action_time < ACTION_COOLDOWN_SECONDS:
        return False

    return True


# =============================
# Display helpers
# =============================
def get_display_label(predicted_label, predicted_confidence):
    """
    Determine the label shown on the webcam preview window.

    If confidence is too low or the prediction is not a target gesture,
    show 'Background' for clarity.

    Args:
        predicted_label (str)
        predicted_confidence (float)

    Returns:
        str
    """
    if predicted_label in ["Next", "Previous"] and predicted_confidence >= MIN_CONFIDENCE_SCORE:
        return predicted_label
    return "Background"


def draw_debug_information(frame, display_label, confidence, stable_label, stable_count):
    """
    Draw user feedback text on the webcam frame.

    Args:
        frame (numpy.ndarray)
        display_label (str)
        confidence (float)
        stable_label (str or None)
        stable_count (int)
    """
    top_text = f"Label: {display_label} | Conf: {confidence:.2f}"
    bottom_text = f"Stable: {stable_label} | Count: {stable_count}"

    cv2.putText(
        frame,
        top_text,
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        bottom_text,
        (20, 80),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 255, 0),
        2
    )


# =============================
# Main control loop
# =============================
def main():
    """
    Main execution function.

    Program flow:
    1. Load model and labels
    2. Open webcam
    3. Capture frames repeatedly
    4. Predict gesture
    5. Apply decision rules
    6. Send keyboard action when conditions are met
    7. Show webcam preview
    """
    gesture_model = load_gesture_model(MODEL_FILE_PATH)
    gesture_labels = load_class_labels(LABEL_FILE_PATH)

    webcam = cv2.VideoCapture(WEBCAM_INDEX)

    if not webcam.isOpened():
        print("Error: Could not open webcam.")
        return

    stable_gesture_label = None
    stable_gesture_count = 0
    last_slide_action_time = 0.0

    print("GestureSlide started.")
    print("Target classes: Background, Next, Previous")
    print("Only Next and Previous can trigger slide actions.")
    print("Press 'q' to quit.")

    while True:
        frame_success, webcam_frame = webcam.read()

        if not frame_success:
            print("Error: Failed to read frame from webcam.")
            break

        # Mirror the webcam frame for easier user interaction
        webcam_frame = cv2.flip(webcam_frame, 1)

        predicted_label, predicted_confidence, _ = predict_gesture(
            gesture_model,
            gesture_labels,
            webcam_frame
        )

        stable_gesture_label, stable_gesture_count = update_stable_gesture_state(
            predicted_label,
            predicted_confidence,
            stable_gesture_label,
            stable_gesture_count
        )

        if should_execute_action(
            stable_gesture_label,
            stable_gesture_count,
            last_slide_action_time
        ):
            execute_slide_action(stable_gesture_label)
            last_slide_action_time = time.time()
            stable_gesture_count = 0

        display_label = get_display_label(predicted_label, predicted_confidence)

        draw_debug_information(
            webcam_frame,
            display_label,
            predicted_confidence,
            stable_gesture_label,
            stable_gesture_count
        )

        cv2.imshow("GestureSlide Webcam", webcam_frame)

        pressed_key = cv2.waitKey(1) & 0xFF
        if pressed_key == ord("q"):
            break

    webcam.release()
    cv2.destroyAllWindows()
    print("Program ended.")


if __name__ == "__main__":
    main()