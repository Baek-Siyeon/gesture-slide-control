==========================================================
Project 01: Omni-Gesture Controller
Team Number: <Enter Your Team Number>
ID: <Enter Your Student ID>
Name: KIM Gahyun, BAEK Siyeon
==========================================================

1. Program Description
   - The Omni-Gesture Controller is an AI-based system designed for hands-free 
     control of applications such as PowerPoint, Instagram, and YouTube.
   - It recognizes user hand gestures in real-time via a webcam and translates 
     them into keyboard events to navigate slides or scroll through content.

2. Library Principles & Logic Analysis
   This program utilizes several external libraries. Based on the analysis of 
   their source code and official documentation, the core logics are as follows:

   (1) OpenCV (cv2)
       - Principle: An open-source computer vision library providing high-level 
         image processing algorithms.
       - Logic: The `VideoCapture` class interfaces with OS-level video APIs to 
         capture frames as numerical matrices (NumPy arrays). We utilize 
         `cv2.flip` for mirroring and `cv2.resize` to match the model's 
         input dimensions.

   (2) TensorFlow Keras (load_model)
       - Principle: A deep learning library for building and running neural networks.
       - Logic: The `load_model` function reconstructs the model architecture 
         from the `.h5` file and maps the saved weights to each layer. The 
         `predict()` function performs forward propagation, calculating the 
         probability distribution across the defined gesture classes.

   (3) NumPy (numpy)
       - Principle: A fundamental package for scientific computing with Python.
       - Logic: It handles the transformation of image data into a 4D tensor 
         [Batch, Height, Width, Channel]. We use vectorized operations for 
         normalization—mapping pixel values from [0, 255] to a [-1, 1] range—
         ensuring faster computation than standard Python loops.

   (4) PyAutoGUI
       - Principle: A cross-platform GUI automation library.
       - Logic: It interacts with the underlying OS event loop to inject virtual 
         keyboard scan codes into the system's input queue, simulating physical 
         key presses (e.g., 'left', 'right', 'up', 'down').

3. Installation & Usage
   (1) Requirements:
       pip install opencv-python tensorflow numpy pyautogui
   
   (2) File Structure:
       - main.py (The source code)
       - keras_Model.h5 (Trained model weights)
       - labels.txt (Classification labels)

   (3) Execution:
       Run the following command in your terminal:
       python main.py
       - Press 'q' or 'ESC' to terminate the program.

4. Core Algorithm & Decision Logic
   - Confidence Filtering: Actions are only considered if the prediction 
     probability exceeds 80% (MIN_CONFIDENCE_SCORE).
   - Stability Validation: To prevent misfires, a gesture must be detected 
     consecutively for 3 frames (MIN_CONSECUTIVE_FRAMES).
   - Cooldown Mechanism: A 1.2-second delay (ACTION_COOLDOWN_SECONDS) is 
     enforced between actions to prevent redundant key inputs.

5. External Data Link
   - Due to file size constraints, high-resolution test videos are hosted externally.
   - Link: <Insert your Google Drive link here>

6. References
   - OpenCV GitHub: https://github.com/opencv/opencv
   - TensorFlow Source: https://github.com/tensorflow/tensorflow
   - PyAutoGUI Docs: https://pyautogui.readthedocs.io/
==========================================================